<?php
   define('EMAIL', 'support@anjanainternational.com');
   define('PASS', 'kamlesh@123');



?>